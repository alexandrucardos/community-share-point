<?php

declare(strict_types=1);

namespace App\Service\Image;

final class ItemImageResolver
{
    private const COLOR_PALETTE = ['2563eb', 'db2777', 'ea580c', '65a30d', '7c3aed', '0891b2'];

    public function __construct(
        private readonly string $awsS3Bucket,
        private readonly string $awsRegion,
        private readonly string $awsS3KeyPrefix,
    ) {
    }

    public function url(string $imageFilename, string $name): string
    {
        if ($imageFilename === '') {
            return $this->placeholderImage($name);
        }

        return sprintf(
            'https://%s.s3.%s.amazonaws.com/%s/%s',
            $this->awsS3Bucket,
            $this->awsRegion,
            trim($this->awsS3KeyPrefix, '/'),
            $imageFilename,
        );
    }

    private function placeholderImage(string $name): string
    {
        $words = preg_split('/\s+/', trim($name), -1, \PREG_SPLIT_NO_EMPTY);
        $initials = strtoupper(($words[0][0] ?? '') . ($words[1][0] ?? ''));
        $color = self::COLOR_PALETTE[crc32($name) % count(self::COLOR_PALETTE)];

        $svg = <<<SVG
            <svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200">
                <rect width="300" height="200" fill="#{$color}"/>
                <text x="150" y="112" font-family="sans-serif" font-size="64" fill="#ffffff" text-anchor="middle">{$initials}</text>
            </svg>
            SVG;

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }
}
